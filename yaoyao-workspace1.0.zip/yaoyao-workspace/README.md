# 🌸 瑶瑶工作台 — Singapore Primary Chinese Creator OS

An AI-powered content intelligence & writing workspace for researching
Singapore Xiaohongshu (小红书) content in the Primary Chinese Education niche.
Built with React + Vite + Tailwind CSS + lucide-react.

## Run locally

```bash
npm install
npm run dev
```

Then open the printed local URL (typically http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview   # optional local check of the production build
```

Output goes to `dist/`.

## Deploy to Vercel

**Option A — Vercel CLI**

```bash
npm install -g vercel
vercel
```

Follow the prompts (accept the auto-detected Vite settings: build
command `npm run build`, output directory `dist`).

**Option B — Vercel dashboard**

1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. In Vercel, click "Add New Project" and import the repo.
3. Framework preset: **Vite** (auto-detected).
   - Build command: `npm run build`
   - Output directory: `dist`
4. Deploy.

No environment variables are required — everything currently runs on
mock data defined in `src/App.jsx`.

## Project structure

```
├── index.html          # HTML entry
├── src/
│   ├── main.jsx         # React root
│   ├── App.jsx           # Entire app: nav, pages, mock data
│   └── index.css          # Tailwind entry
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
└── vercel.json          # SPA rewrite rule
```

## Notes

- All content (viral posts, competitors, keywords, inspirations,
  calendar) is mock data — replace with real API calls when ready.
- Icons: `lucide-react`. Fonts: Baloo 2 (display) + Nunito (body), loaded
  via Google Fonts `@import` in `App.jsx`.
- The UI is mobile-first with a compact left icon rail as requested in
  the design brief.
