import { useState, useMemo } from "react";
import {
  Home, Flame, Users, Search, Lightbulb, PenTool, Calendar as CalendarIcon,
  Database, Settings as SettingsIcon, Heart, MessageCircle, Bookmark,
  TrendingUp, X, ChevronRight, Sparkles, Star, Clock, Filter, Plus,
  Download, Upload, RefreshCw, BarChart3, Eye, ArrowUpRight, Wand2,
  FileText, Video, Hash, Users2, Target, Zap, ChevronDown, Check,
  FolderOpen, Image as ImageIcon, Moon, Bell, Globe, Info, Sun
} from "lucide-react";

/* ============================================================
   🌸 瑶瑶工作台 — Singapore Primary Chinese Creator OS
   Design tokens
   Palette: rose-50/100 (macaron pink), orange-50/100 (peach),
   purple-50/100 (lavender), emerald-50/100 (mint), amber (honey accent)
   Type: "Baloo 2" display (rounded, cute-elegant) + "Nunito" body
   Signature: soft-glass "cloud" cards with a floating mascot corner sticker
   ============================================================ */

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;500;600;700;800&display=swap');`;

/* ---------------- Mock Data ---------------- */

const MASCOTS = ["🐰", "🐻", "🐱", "🐹", "🦊"];

const viralPosts = [
  {
    id: 1,
    cover: "linear-gradient(135deg,#FFD6E8,#FFE4CC)",
    title: "小一妈妈崩溃实录：孩子拼音怎么教都不会！",
    author: "新加坡陪读妈妈",
    date: "2026-07-24",
    likes: 8420,
    collects: 3210,
    comments: 512,
    grade: "P1",
    category: "拼音",
    heat: 96,
    hook: "开头直接用「我快被气哭了」的崩溃语气，制造强烈情绪共鸣",
    structure: "痛点场景 → 具体错误示范 → 转折方法 → 结果对比 → 互动提问",
    triggers: ["焦虑共鸣", "自我怀疑", "解决方案渴望"],
    painPoints: ["家长不会用华语教学术语辅导", "孩子拼音混淆 b/p d/t", "补习班太贵"],
    audience: "P1新手家长，尤其是英文为家庭用语的双语家庭",
    learn: "用「崩溃—反转」结构降低家长防御心理，最后给出可执行清单更容易被收藏",
    followUps: ["拼音易错点合集", "3分钟拼音小游戏", "老师不会说的拼音口诀"],
  },
  {
    id: 2,
    cover: "linear-gradient(135deg,#E5D4FF,#D4F5E9)",
    title: "PSLE华文作文：阅卷官最讨厌看到的5句开头",
    author: "华文老师阿May",
    date: "2026-07-25",
    likes: 15300,
    collects: 9800,
    comments: 843,
    grade: "PSLE",
    category: "写作",
    heat: 99,
    hook: "用「阅卷官视角」制造权威+悬念，家长和学生都想知道内幕",
    structure: "权威身份 → 反面案例 → 原因解析 → 正确示范 → 行动号召",
    triggers: ["权威信任", "怕吃亏心理", "考试焦虑"],
    painPoints: ["学生作文开头千篇一律", "不了解阅卷标准", "缺乏范文参考"],
    audience: "P5-P6备考PSLE的学生家长",
    learn: "「阅卷官视角」是稀缺信息角度，比普通范文分享更有传播力",
    followUps: ["满分作文结尾套路", "阅卷官最爱的成语库", "看图作文黄金公式"],
  },
  {
    id: 3,
    cover: "linear-gradient(135deg,#FFE4CC,#D4F5E9)",
    title: "新加坡小三华文：这样读绘本，词汇量翻倍",
    author: "绘本妈妈Cherry",
    date: "2026-07-23",
    likes: 6210,
    collects: 2870,
    comments: 301,
    grade: "P3",
    category: "阅读",
    heat: 88,
    hook: "用「翻倍」这种可量化结果作为标题钩子，降低理解门槛",
    structure: "结果前置 → 方法拆解（3步）→ 真实案例 → 书单推荐",
    triggers: ["效率渴望", "从众心理"],
    painPoints: ["孩子不爱读中文绘本", "词汇量增长慢", "不知道选什么书"],
    audience: "P2-P3家长，重视亲子共读",
    learn: "步骤化+可量化的标题结构复用性很高，适合迁移到其他学科",
    followUps: ["华文绘本清单P1-P3", "亲子共读话术卡", "词汇卡片制作教程"],
  },
  {
    id: 4,
    cover: "linear-gradient(135deg,#D4F5E9,#FFD6E8)",
    title: "小六生自述：我是怎么从华文C6到A*的",
    author: "学霸姐姐分享",
    date: "2026-07-22",
    likes: 11200,
    collects: 5400,
    comments: 620,
    grade: "P6",
    category: "学习方法",
    heat: 93,
    hook: "第一人称叙事 + 成绩对比制造强烈反差感",
    structure: "低谷描述 → 转折契机 → 方法清单 → 情感升华 → 鼓励收尾",
    triggers: ["逆袭爽感", "希望感", "自我代入"],
    painPoints: ["孩子成绩差自信心低", "不知道从何提升", "家长焦虑传染给孩子"],
    audience: "华文成绩中下的P5-P6学生及家长",
    learn: "第一人称故事体比说教体更容易被转发和收藏",
    followUps: ["逆袭时间表拆解", "错题本制作方法", "考前一周冲刺计划"],
  },
  {
    id: 5,
    cover: "linear-gradient(135deg,#FFD6E8,#E5D4FF)",
    title: "中秋节华文主题：5个亲子活动 + 词汇清单",
    author: "节日教学小分队",
    date: "2026-07-20",
    likes: 4300,
    collects: 3100,
    comments: 210,
    grade: "P2",
    category: "节日",
    heat: 81,
    hook: "节日+清单体，具有强收藏属性和时效性传播",
    structure: "节日引入 → 活动清单 → 配套词汇 → 打印资源提示",
    triggers: ["囤积心理", "节日仪式感"],
    painPoints: ["不知道怎么把节日和华文学习结合", "缺乏现成资源"],
    audience: "重视节日文化教育的P1-P3家长",
    learn: "节日节点内容天然自带流量周期，提前3-5天发布效果最好",
    followUps: ["中秋灯谜合集", "节日主题看图写话", "华族节日日历"],
  },
];

const competitors = [
  {
    id: 1,
    name: "新加坡华文magic",
    avatar: "🦊",
    followers: "12.4万",
    platform: "小红书",
    category: "P1-P3华文启蒙",
    frequency: "每周4篇",
    bestPost: "拼音口诀合集，点赞1.2万",
    style: "干货清单体，封面统一橙色系",
    opening: "用提问式开头「你家孩子也这样吗？」",
    cta: "评论区扣1领取资料包",
    strengths: ["封面识别度高", "资料包引流私域", "更新稳定"],
    notes: "值得学习她的资料包钩子设计，转化率应该很高",
  },
  {
    id: 2,
    name: "阿May老师教华文",
    avatar: "🐻",
    followers: "8.7万",
    platform: "小红书",
    category: "PSLE作文冲刺",
    frequency: "每周3篇",
    bestPost: "阅卷官视角系列，单篇1.5万赞",
    style: "第一人称权威分享，真人出镜",
    opening: "反常识开头，颠覆家长认知",
    cta: "私信领取范文合集",
    strengths: ["权威人设强", "系列化内容", "评论区互动率高"],
    notes: "她的系列命名「阅卷官说」形成记忆点，可以借鉴命名思路",
  },
  {
    id: 3,
    name: "绘本妈妈Cherry",
    avatar: "🐰",
    followers: "5.2万",
    platform: "小红书",
    category: "亲子共读",
    frequency: "每周2篇",
    bestPost: "绘本读法翻倍词汇量，8千赞",
    style: "生活化场景 + 温暖滤镜",
    opening: "生活片段引入，情感先行",
    cta: "关注解锁书单合集",
    strengths: ["画面温馨有辨识度", "情感共鸣强"],
    notes: "适合情感向选题参考她的镜头语言和文案节奏",
  },
];

const keywordData = [
  { word: "拼音口诀", volume: 8900, grade: "P1", type: "热搜词" },
  { word: "看图写话怎么教", volume: 6400, grade: "P2", type: "家长提问" },
  { word: "PSLE作文模板", volume: 12100, grade: "PSLE", type: "热搜词" },
  { word: "华文补习值得吗", volume: 4200, grade: "P5", type: "家长提问" },
  { word: "成语接龙", volume: 3300, grade: "P3", type: "评论高频词" },
  { word: "中秋节看图作文", volume: 2100, grade: "P2", type: "节日话题" },
  { word: "华文阅读理解技巧", volume: 7600, grade: "P6", type: "热搜词" },
  { word: "双语家庭华文启蒙", volume: 5100, grade: "P1", type: "内容缺口" },
  { word: "MOE华文课纲变化", volume: 1900, grade: "全年级", type: "MOE话题" },
  { word: "作文好词好句积累", volume: 9200, grade: "P4", type: "热搜词" },
];

const inspirations = [
  {
    id: 1,
    fromPost: "小一妈妈崩溃实录：孩子拼音怎么教都不会！",
    idea: "做一个「拼音急救包」系列，每篇解决一个具体易错点",
    angle: "痛点解决型",
    hook: "「孩子又把 b 读成 p？」",
    audience: "P1家长",
    difficulty: "低",
    priority: "高",
    status: "待写作",
  },
  {
    id: 2,
    fromPost: "PSLE华文作文：阅卷官最讨厌看到的5句开头",
    idea: "反向盘点「阅卷官最喜欢的5种结尾」形成系列对照",
    angle: "权威揭秘型",
    hook: "「同样的作文，为什么她多拿了8分？」",
    audience: "P6家长与学生",
    difficulty: "中",
    priority: "高",
    status: "构思中",
  },
  {
    id: 3,
    fromPost: "新加坡小三华文：这样读绘本，词汇量翻倍",
    idea: "整理一份「新加坡本地可借阅」的华文绘本清单，附借阅渠道",
    angle: "资源清单型",
    hook: "「不用买，图书馆就能借到的10本神级绘本」",
    audience: "P1-P3家长",
    difficulty: "低",
    priority: "中",
    status: "已保存",
  },
];

const calendarPosts = [
  { id: 1, title: "拼音急救包 Vol.1：b/p 傻傻分不清", date: "2026-07-29", status: "草稿" },
  { id: 2, title: "阅卷官最爱的5种作文结尾", date: "2026-07-31", status: "已排期" },
  { id: 3, title: "图书馆免费借！10本华文绘本清单", date: "2026-08-02", status: "已排期" },
  { id: 4, title: "中秋节主题看图写话素材包", date: "2026-08-05", status: "草稿" },
  { id: 5, title: "PSLE华文冲刺：最后30天怎么复习", date: "2026-07-27", status: "已发布" },
];

const gradeFilters = ["全部", "P1", "P2", "P3", "P4", "P5", "P6", "PSLE"];
const categoryFilters = ["全部", "拼音", "写作", "阅读", "词汇", "学习方法", "节日", "家长锦囊"];

const NAV_ITEMS = [
  { key: "dashboard", label: "首页", icon: Home },
  { key: "radar", label: "爆款雷达", icon: Flame },
  { key: "competitors", label: "对标账号", icon: Users },
  { key: "keywords", label: "热词中心", icon: Search },
  { key: "inspiration", label: "灵感库", icon: Lightbulb },
  { key: "studio", label: "AI 创作室", icon: PenTool },
  { key: "calendar", label: "发布计划", icon: CalendarIcon },
  { key: "data", label: "数据中心", icon: Database },
  { key: "settings", label: "设置", icon: SettingsIcon },
];

/* ---------------- Shared UI atoms ---------------- */

function GlassCard({ children, className = "", mascot }) {
  return (
    <div
      className={`relative rounded-3xl bg-white/70 backdrop-blur-xl border border-white shadow-[0_8px_30px_rgba(214,178,202,0.25)] ${className}`}
    >
      {mascot && (
        <span className="absolute -top-3 -right-3 text-2xl drop-shadow-sm select-none">{mascot}</span>
      )}
      {children}
    </div>
  );
}

function Pill({ children, tone = "pink" }) {
  const tones = {
    pink: "bg-rose-100 text-rose-500",
    peach: "bg-orange-100 text-orange-500",
    lavender: "bg-purple-100 text-purple-500",
    mint: "bg-emerald-100 text-emerald-600",
    amber: "bg-amber-100 text-amber-600",
  };
  return (
    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${tones[tone]}`}>
      {children}
    </span>
  );
}

function EmptyState({ mascot = "🐰", title, subtitle }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-6">
      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-rose-100 to-orange-100 flex items-center justify-center text-4xl mb-4 shadow-inner">
        {mascot}
      </div>
      <p className="font-bold text-stone-600 mb-1" style={{ fontFamily: "'Baloo 2', sans-serif" }}>
        {title}
      </p>
      <p className="text-sm text-stone-400">{subtitle}</p>
    </div>
  );
}

function SectionTitle({ icon: Icon, title, action }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-rose-200 to-orange-100 flex items-center justify-center">
          <Icon size={16} className="text-rose-500" />
        </div>
        <h2 className="font-extrabold text-stone-700 text-lg" style={{ fontFamily: "'Baloo 2', sans-serif" }}>
          {title}
        </h2>
      </div>
      {action}
    </div>
  );
}

function PrimaryButton({ children, onClick, className = "", icon: Icon }) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-br from-rose-300 to-orange-200 text-white text-sm font-bold shadow-md shadow-rose-200/60 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all ${className}`}
    >
      {Icon && <Icon size={15} />}
      {children}
    </button>
  );
}

function GhostButton({ children, onClick, className = "", icon: Icon, active }) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold transition-all ${
        active
          ? "bg-rose-400 text-white shadow-sm"
          : "bg-white/70 text-stone-500 border border-rose-100 hover:bg-rose-50"
      } ${className}`}
    >
      {Icon && <Icon size={13} />}
      {children}
    </button>
  );
}

/* ---------------- Dashboard ---------------- */

function Dashboard({ setActive, setSelectedPost }) {
  const hour = new Date().getHours();
  const greet = hour < 12 ? "早安" : hour < 18 ? "午安" : "晚安";
  return (
    <div className="space-y-5 pb-24">
      <GlassCard className="p-5 overflow-hidden">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-stone-400 text-xs font-semibold mb-1">{greet}，创作者 ✨</p>
            <h1 className="text-xl font-extrabold text-stone-700" style={{ fontFamily: "'Baloo 2', sans-serif" }}>
              今天也要发现好内容哦 🐰
            </h1>
            <p className="text-sm text-stone-400 mt-1">已连续更新灵感库 <b className="text-rose-400">7</b> 天，继续加油！</p>
          </div>
          <div className="text-5xl">🐰</div>
        </div>
      </GlassCard>

      <div className="grid grid-cols-2 gap-3">
        <GlassCard className="p-4">
          <p className="text-xs text-stone-400 font-semibold mb-1">本周写作进度</p>
          <p className="text-2xl font-extrabold text-rose-400" style={{ fontFamily: "'Baloo 2', sans-serif" }}>3/5</p>
          <div className="w-full h-2 rounded-full bg-rose-100 mt-2 overflow-hidden">
            <div className="h-full w-3/5 rounded-full bg-gradient-to-r from-rose-300 to-orange-300" />
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs text-stone-400 font-semibold mb-1">发布连续天数</p>
          <p className="text-2xl font-extrabold text-emerald-400" style={{ fontFamily: "'Baloo 2', sans-serif" }}>7 天 🔥</p>
          <p className="text-xs text-stone-400 mt-2">周目标：4篇 · 已完成 3篇</p>
        </GlassCard>
      </div>

      <div>
        <SectionTitle
          icon={Flame}
          title="今日爆款速览"
          action={<button onClick={() => setActive("radar")} className="text-xs font-bold text-rose-400 flex items-center gap-0.5">查看全部 <ChevronRight size={13} /></button>}
        />
        <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
          {viralPosts.slice(0, 3).map((p) => (
            <div
              key={p.id}
              onClick={() => { setSelectedPost(p); setActive("radar"); }}
              className="min-w-[180px] rounded-2xl bg-white/70 border border-white shadow-sm p-3 cursor-pointer hover:-translate-y-1 transition-transform"
            >
              <div className="h-20 rounded-xl mb-2" style={{ background: p.cover }} />
              <p className="text-xs font-bold text-stone-600 line-clamp-2 leading-snug">{p.title}</p>
              <div className="flex items-center gap-1 mt-2 text-[11px] text-stone-400">
                <Heart size={11} className="text-rose-300" /> {p.likes.toLocaleString()}
                <span className="ml-auto font-bold text-orange-400">🔥{p.heat}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <GlassCard className="p-4">
        <SectionTitle icon={Search} title="今日热词" />
        <div className="flex flex-wrap gap-2">
          {keywordData.slice(0, 6).map((k) => (
            <Pill key={k.word} tone={["pink", "peach", "lavender", "mint", "amber"][k.word.length % 5]}>
              # {k.word}
            </Pill>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-4">
        <SectionTitle icon={Users} title="对标账号更新" />
        <div className="space-y-2">
          {competitors.slice(0, 2).map((c) => (
            <div key={c.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-rose-50/60 transition-colors">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-rose-100 to-purple-100 flex items-center justify-center text-lg">{c.avatar}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-stone-600 truncate">{c.name}</p>
                <p className="text-xs text-stone-400 truncate">发布了新爆款：{c.bestPost}</p>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-4 bg-gradient-to-br from-purple-50/80 to-rose-50/80" mascot="💡">
        <div className="flex items-center gap-2 mb-1.5">
          <Sparkles size={15} className="text-purple-400" />
          <p className="font-extrabold text-stone-700 text-sm" style={{ fontFamily: "'Baloo 2', sans-serif" }}>今日AI推荐选题</p>
        </div>
        <p className="text-sm text-stone-500 leading-relaxed">「PSLE最后30天冲刺清单」正在起势，同类内容近7天热度上升42%，建议本周安排产出。</p>
        <PrimaryButton className="mt-3" icon={Wand2} onClick={() => setActive("studio")}>去创作</PrimaryButton>
      </GlassCard>

      <GlassCard className="p-4">
        <SectionTitle icon={FileText} title="速记 · 灵感碎片" />
        <textarea
          placeholder="随手记下一个灵感……🐹"
          className="w-full text-sm rounded-xl border border-rose-100 bg-rose-50/40 p-3 resize-none focus:outline-none focus:ring-2 focus:ring-rose-200 placeholder:text-stone-400"
          rows={3}
        />
      </GlassCard>
    </div>
  );
}

/* ---------------- 爆款雷达 Viral Radar ---------------- */

function ViralRadar({ selectedPost, setSelectedPost }) {
  const [grade, setGrade] = useState("全部");
  const [category, setCategory] = useState("全部");
  const [saved, setSaved] = useState({});

  const filtered = viralPosts.filter(
    (p) => (grade === "全部" || p.grade === grade) && (category === "全部" || p.category === category)
  );

  return (
    <div className="pb-24">
      <SectionTitle icon={Flame} title="爆款雷达" action={<Pill tone="peach">今日 {filtered.length} 篇</Pill>} />

      <div className="flex gap-2 overflow-x-auto pb-2 mb-2 -mx-1 px-1">
        {gradeFilters.map((g) => (
          <GhostButton key={g} active={grade === g} onClick={() => setGrade(g)}>{g}</GhostButton>
        ))}
      </div>
      <div className="flex gap-2 overflow-x-auto pb-3 mb-2 -mx-1 px-1">
        {categoryFilters.map((c) => (
          <GhostButton key={c} active={category === c} onClick={() => setCategory(c)}>{c}</GhostButton>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState mascot="🦊" title="这个分类还没有爆款～" subtitle="换个筛选条件试试看吧" />
      ) : (
        <div className="space-y-4">
          {filtered.map((p) => (
            <GlassCard key={p.id} className="p-3 cursor-pointer" >
              <div onClick={() => setSelectedPost(p)} className="flex gap-3">
                <div className="w-20 h-24 rounded-2xl shrink-0" style={{ background: p.cover }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-1">
                    <Pill tone="pink">{p.grade}</Pill>
                    <Pill tone="lavender">{p.category}</Pill>
                    <span className="ml-auto text-xs font-extrabold text-orange-400 flex items-center gap-0.5">🔥{p.heat}</span>
                  </div>
                  <p className="text-sm font-bold text-stone-700 leading-snug line-clamp-2">{p.title}</p>
                  <p className="text-xs text-stone-400 mt-1">{p.author} · {p.date}</p>
                  <div className="flex items-center gap-3 mt-2 text-[11px] text-stone-400">
                    <span className="flex items-center gap-0.5"><Heart size={11} className="text-rose-300" />{p.likes.toLocaleString()}</span>
                    <span className="flex items-center gap-0.5"><Bookmark size={11} className="text-amber-300" />{p.collects.toLocaleString()}</span>
                    <span className="flex items-center gap-0.5"><MessageCircle size={11} className="text-purple-300" />{p.comments}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-3 pt-3 border-t border-rose-50">
                <button
                  onClick={(e) => { e.stopPropagation(); setSaved((s) => ({ ...s, [p.id]: !s[p.id] })); }}
                  className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-xl text-xs font-bold transition-colors ${saved[p.id] ? "bg-rose-400 text-white" : "bg-rose-50 text-rose-400"}`}
                >
                  <Bookmark size={13} /> {saved[p.id] ? "已保存" : "保存灵感"}
                </button>
                <button onClick={() => setSelectedPost(p)} className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-xl text-xs font-bold bg-purple-50 text-purple-400">
                  <Sparkles size={13} /> AI分析
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {selectedPost && <PostDetailModal post={selectedPost} onClose={() => setSelectedPost(null)} />}
    </div>
  );
}

function PostDetailModal({ post, onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-stone-800/40 backdrop-blur-sm" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md max-h-[88vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-gradient-to-b from-white to-rose-50 p-5 shadow-2xl"
      >
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5">
            <Pill tone="pink">{post.grade}</Pill>
            <Pill tone="lavender">{post.category}</Pill>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm">
            <X size={15} className="text-stone-400" />
          </button>
        </div>

        <div className="h-32 rounded-2xl mb-3" style={{ background: post.cover }} />
        <h3 className="font-extrabold text-stone-700 text-base leading-snug mb-1" style={{ fontFamily: "'Baloo 2', sans-serif" }}>{post.title}</h3>
        <p className="text-xs text-stone-400 mb-3">{post.author} · {post.date} · 🔥热度 {post.heat}</p>

        <div className="grid grid-cols-3 gap-2 mb-4">
          <div className="rounded-xl bg-white/70 p-2 text-center">
            <p className="text-sm font-extrabold text-rose-400">{post.likes.toLocaleString()}</p>
            <p className="text-[10px] text-stone-400">点赞</p>
          </div>
          <div className="rounded-xl bg-white/70 p-2 text-center">
            <p className="text-sm font-extrabold text-amber-400">{post.collects.toLocaleString()}</p>
            <p className="text-[10px] text-stone-400">收藏</p>
          </div>
          <div className="rounded-xl bg-white/70 p-2 text-center">
            <p className="text-sm font-extrabold text-purple-400">{post.comments}</p>
            <p className="text-[10px] text-stone-400">评论</p>
          </div>
        </div>

        <div className="space-y-3">
          <AnalysisBlock icon={Zap} title="爆款开头钩子" tone="pink">{post.hook}</AnalysisBlock>
          <AnalysisBlock icon={BarChart3} title="内容结构拆解" tone="lavender">{post.structure}</AnalysisBlock>
          <AnalysisBlock icon={Heart} title="情绪触发点" tone="peach">
            <div className="flex flex-wrap gap-1.5">{post.triggers.map((t) => <Pill key={t} tone="peach">{t}</Pill>)}</div>
          </AnalysisBlock>
          <AnalysisBlock icon={Target} title="痛点洞察" tone="mint">
            <ul className="list-disc list-inside space-y-0.5">{post.painPoints.map((t) => <li key={t}>{t}</li>)}</ul>
          </AnalysisBlock>
          <AnalysisBlock icon={Users2} title="目标受众" tone="lavender">{post.audience}</AnalysisBlock>
          <AnalysisBlock icon={Lightbulb} title="我能学到什么" tone="amber">{post.learn}</AnalysisBlock>
          <AnalysisBlock icon={ArrowUpRight} title="可延伸选题" tone="pink">
            <div className="flex flex-wrap gap-1.5">{post.followUps.map((t) => <Pill key={t} tone="pink">{t}</Pill>)}</div>
          </AnalysisBlock>
        </div>

        <div className="flex gap-2 mt-5">
          <PrimaryButton className="flex-1 justify-center" icon={Bookmark}>存入灵感库</PrimaryButton>
          <PrimaryButton className="flex-1 justify-center !from-purple-300 !to-purple-200" icon={Wand2}>去创作原创内容</PrimaryButton>
        </div>
      </div>
    </div>
  );
}

function AnalysisBlock({ icon: Icon, title, tone, children }) {
  const tones = { pink: "text-rose-400", lavender: "text-purple-400", peach: "text-orange-400", mint: "text-emerald-500", amber: "text-amber-500" };
  return (
    <div className="rounded-2xl bg-white/70 p-3">
      <div className="flex items-center gap-1.5 mb-1.5">
        <Icon size={14} className={tones[tone]} />
        <p className="text-xs font-extrabold text-stone-600">{title}</p>
      </div>
      <div className="text-xs text-stone-500 leading-relaxed">{children}</div>
    </div>
  );
}

/* ---------------- 对标账号 Competitors ---------------- */

function Competitors() {
  const [expanded, setExpanded] = useState(null);
  return (
    <div className="pb-24">
      <SectionTitle icon={Users} title="对标账号" action={<PrimaryButton icon={Plus}>添加账号</PrimaryButton>} />
      <div className="space-y-3">
        {competitors.map((c) => (
          <GlassCard key={c.id} className="p-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => setExpanded(expanded === c.id ? null : c.id)}>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-100 to-purple-100 flex items-center justify-center text-2xl">{c.avatar}</div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-stone-700 text-sm truncate">{c.name}</p>
                <p className="text-xs text-stone-400">{c.platform} · {c.followers}粉丝 · {c.frequency}</p>
              </div>
              <ChevronDown size={16} className={`text-stone-300 transition-transform ${expanded === c.id ? "rotate-180" : ""}`} />
            </div>
            <div className="flex flex-wrap gap-1.5 mt-2">
              <Pill tone="lavender">{c.category}</Pill>
            </div>
            {expanded === c.id && (
              <div className="mt-3 pt-3 border-t border-rose-50 space-y-2 text-xs text-stone-500">
                <p><b className="text-stone-600">最佳表现：</b>{c.bestPost}</p>
                <p><b className="text-stone-600">内容风格：</b>{c.style}</p>
                <p><b className="text-stone-600">开头风格：</b>{c.opening}</p>
                <p><b className="text-stone-600">CTA方式：</b>{c.cta}</p>
                <div className="flex flex-wrap gap-1.5">{c.strengths.map((s) => <Pill key={s} tone="mint">{s}</Pill>)}</div>
                <div className="rounded-xl bg-amber-50 p-2 text-amber-600"><b>我的笔记：</b>{c.notes}</div>
              </div>
            )}
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ---------------- 热词中心 Keywords ---------------- */

function Keywords() {
  const [grade, setGrade] = useState("全部");
  const filtered = keywordData.filter((k) => grade === "全部" || k.grade === grade || k.grade === "全年级");
  const typeTone = { "热搜词": "pink", "家长提问": "lavender", "评论高频词": "mint", "节日话题": "peach", "内容缺口": "amber", "MOE话题": "lavender" };
  return (
    <div className="pb-24">
      <SectionTitle icon={Search} title="热词中心" />
      <div className="flex gap-2 overflow-x-auto pb-3 mb-2 -mx-1 px-1">
        {gradeFilters.map((g) => <GhostButton key={g} active={grade === g} onClick={() => setGrade(g)}>{g}</GhostButton>)}
      </div>
      <div className="space-y-2">
        {filtered.map((k) => (
          <GlassCard key={k.word} className="p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-rose-100 to-orange-100 flex items-center justify-center">
              <Hash size={15} className="text-rose-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-stone-700 truncate">{k.word}</p>
              <p className="text-xs text-stone-400">{k.grade} · 搜索热度 {k.volume.toLocaleString()}</p>
            </div>
            <Pill tone={typeTone[k.type] || "pink"}>{k.type}</Pill>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ---------------- 灵感库 Inspiration ---------------- */

function Inspiration() {
  const priorityTone = { "高": "pink", "中": "amber", "低": "mint" };
  return (
    <div className="pb-24">
      <SectionTitle icon={Lightbulb} title="灵感库" action={<Pill tone="lavender">{inspirations.length} 条灵感</Pill>} />
      {inspirations.length === 0 ? (
        <EmptyState mascot="🐹" title="灵感库还空空的" subtitle="去爆款雷达保存第一个灵感吧" />
      ) : (
        <div className="space-y-3">
          {inspirations.map((i) => (
            <GlassCard key={i.id} className="p-4" mascot={MASCOTS[i.id % MASCOTS.length]}>
              <p className="text-[11px] text-stone-400 mb-1">灵感来源：{i.fromPost}</p>
              <p className="font-bold text-sm text-stone-700 mb-2 leading-snug">{i.idea}</p>
              <div className="grid grid-cols-2 gap-2 text-xs text-stone-500 mb-2">
                <p><b className="text-stone-600">角度：</b>{i.angle}</p>
                <p><b className="text-stone-600">受众：</b>{i.audience}</p>
                <p><b className="text-stone-600">难度：</b>{i.difficulty}</p>
                <p><b className="text-stone-600">状态：</b>{i.status}</p>
              </div>
              <div className="rounded-xl bg-rose-50 p-2 text-xs text-rose-500 mb-3"><b>钩子：</b>{i.hook}</div>
              <div className="flex items-center gap-2">
                <Pill tone={priorityTone[i.priority]}>优先级 {i.priority}</Pill>
                <PrimaryButton className="ml-auto" icon={Wand2}>生成更多创意</PrimaryButton>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- AI 创作室 AI Studio ---------------- */

const studioFns = [
  { key: "titles", label: "生成10个标题", icon: FileText },
  { key: "hooks", label: "生成5个开头钩子", icon: Zap },
  { key: "fullpost", label: "生成完整笔记", icon: PenTool },
  { key: "carousel", label: "生成图文卡片文案", icon: ImageIcon },
  { key: "video", label: "生成短视频脚本", icon: Video },
  { key: "cta", label: "生成互动引导CTA", icon: Target },
  { key: "hashtag", label: "生成话题标签", icon: Hash },
  { key: "parent", label: "生成家长版文案", icon: Users2 },
  { key: "teacher", label: "生成教师版文案", icon: Star },
];

const rewriteFns = ["用我的风格改写", "更爆款一点", "更专业一点", "更亲切一点"];

const mockOutputs = {
  titles: [
    "拼音总读错？P1家长的急救清单来了",
    "别再靠吼了！3招搞定b/p分不清",
    "老师不会主动说的拼音小秘密",
    "新加坡双语家庭华文启蒙避坑指南",
    "孩子拼音总出错，问题可能不在他",
  ],
  hooks: [
    "「妈妈我又读错了」——这句话你是不是每天都听到？",
    "别急着骂孩子，先看看是不是方法错了",
    "新加坡老师私下都在用的3个拼音小技巧",
    "我用这招，一周解决了孩子的拼音焦虑",
    "如果你家孩子也这样，先别急着报补习班",
  ],
};

function AIStudio() {
  const [source, setSource] = useState(viralPosts[0].id);
  const [activeFn, setActiveFn] = useState(null);
  const post = viralPosts.find((p) => p.id === source);

  return (
    <div className="pb-24">
      <SectionTitle icon={PenTool} title="AI 创作室" />

      <GlassCard className="p-4 mb-4" mascot="🐻">
        <p className="text-xs font-bold text-stone-500 mb-2">1. 选择灵感来源（仅提取结构，不会照搬原文）</p>
        <select
          value={source}
          onChange={(e) => setSource(Number(e.target.value))}
          className="w-full text-sm rounded-xl border border-rose-100 bg-white/80 p-2.5 font-semibold text-stone-600 focus:outline-none focus:ring-2 focus:ring-rose-200"
        >
          {viralPosts.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
        </select>
        <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-stone-500">
          <div className="rounded-lg bg-rose-50 p-2 text-center"><b className="block text-stone-600">结构</b>已提取</div>
          <div className="rounded-lg bg-orange-50 p-2 text-center"><b className="block text-stone-600">痛点</b>{post.painPoints.length}个</div>
          <div className="rounded-lg bg-purple-50 p-2 text-center"><b className="block text-stone-600">情绪点</b>{post.triggers.length}个</div>
        </div>
      </GlassCard>

      <p className="text-xs font-bold text-stone-500 mb-2 px-1">2. 选择生成功能</p>
      <div className="grid grid-cols-3 gap-2 mb-4">
        {studioFns.map((f) => (
          <button
            key={f.key}
            onClick={() => setActiveFn(f.key)}
            className={`flex flex-col items-center gap-1.5 rounded-2xl p-3 text-center transition-all ${
              activeFn === f.key ? "bg-gradient-to-br from-rose-300 to-orange-200 text-white shadow-md" : "bg-white/70 text-stone-500"
            }`}
          >
            <f.icon size={17} />
            <span className="text-[10px] font-bold leading-tight">{f.label}</span>
          </button>
        ))}
      </div>

      {activeFn && (
        <GlassCard className="p-4 mb-4">
          <div className="flex items-center gap-1.5 mb-2">
            <Sparkles size={14} className="text-purple-400" />
            <p className="text-xs font-extrabold text-stone-600">{studioFns.find((f) => f.key === activeFn)?.label} · 结果</p>
          </div>
          <div className="space-y-1.5">
            {(mockOutputs[activeFn] || mockOutputs.titles).map((line, idx) => (
              <div key={idx} className="text-xs rounded-xl bg-rose-50/70 p-2.5 text-stone-600 leading-relaxed">
                {idx + 1}. {line}
              </div>
            ))}
          </div>
          <div className="flex gap-2 mt-3 flex-wrap">
            {rewriteFns.map((r) => <GhostButton key={r} icon={RefreshCw}>{r}</GhostButton>)}
          </div>
        </GlassCard>
      )}

      {!activeFn && <EmptyState mascot="🐱" title="选一个生成功能开始创作吧" subtitle="AI只提取结构和情绪，绝不照搬原文" />}
    </div>
  );
}

/* ---------------- 发布计划 Calendar ---------------- */

function PublishCalendar() {
  const [tab, setTab] = useState("全部");
  const tabs = ["全部", "草稿", "已排期", "已发布"];
  const filtered = calendarPosts.filter((p) => tab === "全部" || p.status === tab);
  const statusTone = { "草稿": "amber", "已排期": "lavender", "已发布": "mint" };

  return (
    <div className="pb-24">
      <SectionTitle icon={CalendarIcon} title="发布计划" action={<PrimaryButton icon={Plus}>新建计划</PrimaryButton>} />
      <div className="flex gap-2 mb-3">
        {tabs.map((t) => <GhostButton key={t} active={tab === t} onClick={() => setTab(t)}>{t}</GhostButton>)}
      </div>
      <div className="space-y-2">
        {filtered.map((p) => (
          <GlassCard key={p.id} className="p-3 flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-rose-100 to-purple-100 flex flex-col items-center justify-center text-rose-400">
              <span className="text-[10px] font-bold leading-none">{p.date.slice(5, 7)}月</span>
              <span className="text-sm font-extrabold leading-none">{p.date.slice(8, 10)}</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-stone-700 truncate">{p.title}</p>
              <p className="text-xs text-stone-400">{p.date}</p>
            </div>
            <Pill tone={statusTone[p.status]}>{p.status}</Pill>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

/* ---------------- 数据中心 Data Center ---------------- */

const STAT_TONE_CLASSES = {
  pink: { bg: "bg-rose-100", text: "text-rose-400" },
  lavender: { bg: "bg-purple-100", text: "text-purple-400" },
  mint: { bg: "bg-emerald-100", text: "text-emerald-400" },
  amber: { bg: "bg-amber-100", text: "text-amber-400" },
};

function DataCenter() {
  const stats = [
    { label: "爆款存档", value: viralPosts.length, icon: Flame, tone: "pink" },
    { label: "热词存档", value: keywordData.length, icon: Hash, tone: "lavender" },
    { label: "对标账号", value: competitors.length, icon: Users, tone: "mint" },
    { label: "灵感笔记", value: inspirations.length, icon: Lightbulb, tone: "amber" },
  ];
  const folders = ["图片素材", "截图收藏", "内容模板", "写作历史"];
  return (
    <div className="pb-24">
      <SectionTitle icon={Database} title="数据中心" />
      <div className="grid grid-cols-2 gap-3 mb-4">
        {stats.map((s) => (
          <GlassCard key={s.label} className="p-4">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-2 ${STAT_TONE_CLASSES[s.tone].bg}`}>
              <s.icon size={15} className={STAT_TONE_CLASSES[s.tone].text} />
            </div>
            <p className="text-xl font-extrabold text-stone-700" style={{ fontFamily: "'Baloo 2', sans-serif" }}>{s.value}</p>
            <p className="text-xs text-stone-400">{s.label}</p>
          </GlassCard>
        ))}
      </div>

      <GlassCard className="p-4 mb-4">
        <p className="text-xs font-extrabold text-stone-500 mb-2">我的内容资产库</p>
        <div className="grid grid-cols-2 gap-2">
          {folders.map((f) => (
            <div key={f} className="flex items-center gap-2 rounded-xl bg-rose-50/60 p-2.5">
              <FolderOpen size={15} className="text-orange-400" />
              <span className="text-xs font-bold text-stone-600">{f}</span>
            </div>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-4 mb-4">
        <p className="text-xs font-extrabold text-stone-500 mb-2">备份与同步</p>
        <div className="flex items-center justify-between py-1.5">
          <span className="text-xs text-stone-500">自动备份</span>
          <Pill tone="mint">已开启</Pill>
        </div>
        <div className="flex items-center justify-between py-1.5">
          <span className="text-xs text-stone-500">云端同步</span>
          <Pill tone="amber">即将上线</Pill>
        </div>
      </GlassCard>

      <div className="grid grid-cols-3 gap-2">
        <GhostButton icon={Download} className="justify-center w-full py-2.5">导出 JSON</GhostButton>
        <GhostButton icon={Download} className="justify-center w-full py-2.5">导出 CSV</GhostButton>
        <GhostButton icon={Download} className="justify-center w-full py-2.5">导出 MD</GhostButton>
      </div>
      <GhostButton icon={Upload} className="justify-center w-full py-2.5 mt-2">导入 / 恢复备份</GhostButton>
    </div>
  );
}

/* ---------------- 设置 Settings ---------------- */

function Settings() {
  const [dark, setDark] = useState(false);
  const [notif, setNotif] = useState(true);
  return (
    <div className="pb-24 space-y-3">
      <SectionTitle icon={SettingsIcon} title="设置" />
      <GlassCard className="p-4 divide-y divide-rose-50">
        <SettingRow icon={dark ? Moon : Sun} label="外观主题" value={dark ? "深色模式" : "浅色模式"} onClick={() => setDark(!dark)} />
        <SettingRow icon={Bell} label="通知提醒" value={notif ? "已开启" : "已关闭"} onClick={() => setNotif(!notif)} />
        <SettingRow icon={Globe} label="语言" value="简体中文" />
        <SettingRow icon={Database} label="备份设置" value="每日自动备份" />
        <SettingRow icon={Info} label="关于瑶瑶工作台" value="v1.0.0" />
      </GlassCard>
      <div className="text-center text-xs text-stone-300 pt-4">🌸 瑶瑶工作台 · 用心陪伴每一次创作</div>
    </div>
  );
}

function SettingRow({ icon: Icon, label, value, onClick }) {
  return (
    <div onClick={onClick} className="flex items-center gap-3 py-3 cursor-pointer">
      <div className="w-8 h-8 rounded-xl bg-rose-50 flex items-center justify-center"><Icon size={15} className="text-rose-400" /></div>
      <span className="text-sm font-semibold text-stone-600 flex-1">{label}</span>
      <span className="text-xs text-stone-400">{value}</span>
      <ChevronRight size={14} className="text-stone-300" />
    </div>
  );
}

/* ---------------- Global Search ---------------- */

function GlobalSearch({ query, setQuery, onClose }) {
  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return [
      ...viralPosts.filter((p) => p.title.toLowerCase().includes(q)).map((p) => ({ type: "爆款", label: p.title, icon: Flame })),
      ...keywordData.filter((k) => k.word.toLowerCase().includes(q)).map((k) => ({ type: "热词", label: k.word, icon: Hash })),
      ...competitors.filter((c) => c.name.toLowerCase().includes(q)).map((c) => ({ type: "账号", label: c.name, icon: Users })),
      ...inspirations.filter((i) => i.idea.toLowerCase().includes(q)).map((i) => ({ type: "灵感", label: i.idea, icon: Lightbulb })),
    ];
  }, [query]);

  return (
    <div className="fixed inset-0 z-50 bg-stone-800/40 backdrop-blur-sm flex flex-col" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="bg-white rounded-b-3xl p-4 shadow-lg">
        <div className="flex items-center gap-2 bg-rose-50 rounded-2xl px-3 py-2.5">
          <Search size={16} className="text-rose-300" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索爆款、热词、账号、灵感……"
            className="flex-1 bg-transparent text-sm focus:outline-none placeholder:text-stone-400"
          />
          <button onClick={onClose}><X size={16} className="text-stone-400" /></button>
        </div>
        <div className="mt-3 max-h-[60vh] overflow-y-auto space-y-1.5">
          {query.trim() === "" ? (
            <p className="text-xs text-stone-400 text-center py-6">输入关键词，全局搜索所有内容 🐰</p>
          ) : results.length === 0 ? (
            <EmptyState mascot="🐹" title="没有找到相关内容" subtitle="换个关键词试试吧" />
          ) : (
            results.map((r, idx) => (
              <div key={idx} className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-rose-50">
                <r.icon size={14} className="text-rose-400 shrink-0" />
                <span className="text-xs text-stone-400 shrink-0">{r.type}</span>
                <span className="text-sm text-stone-600 truncate">{r.label}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState("dashboard");
  const [selectedPost, setSelectedPost] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");

  const pageMeta = NAV_ITEMS.find((n) => n.key === active);

  const renderPage = () => {
    switch (active) {
      case "dashboard": return <Dashboard setActive={setActive} setSelectedPost={setSelectedPost} />;
      case "radar": return <ViralRadar selectedPost={selectedPost} setSelectedPost={setSelectedPost} />;
      case "competitors": return <Competitors />;
      case "keywords": return <Keywords />;
      case "inspiration": return <Inspiration />;
      case "studio": return <AIStudio />;
      case "calendar": return <PublishCalendar />;
      case "data": return <DataCenter />;
      case "settings": return <Settings />;
      default: return null;
    }
  };

  return (
    <div style={{ fontFamily: "'Nunito', sans-serif" }} className="min-h-screen bg-gradient-to-b from-rose-50 via-orange-50/40 to-purple-50/40 text-stone-700 flex">
      <style>{`${FONT_IMPORT}
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-thumb{background:#FBCFE8;border-radius:10px}
        .line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
        .line-clamp-3{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
        @keyframes floatY{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
        .float{animation:floatY 3.5s ease-in-out infinite}
      `}</style>

      {/* Left icon rail — sidebar nav, mobile-first slim width */}
      <nav className="w-16 shrink-0 min-h-screen bg-white/60 backdrop-blur-xl border-r border-white flex flex-col items-center py-4 gap-1 sticky top-0">
        <div className="text-2xl mb-3 float">🌸</div>
        {NAV_ITEMS.map((item) => {
          const isActive = active === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setActive(item.key)}
              className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
                isActive ? "bg-gradient-to-br from-rose-300 to-orange-200 shadow-md shadow-rose-200/70 scale-105" : "hover:bg-rose-50"
              }`}
              title={item.label}
            >
              <item.icon size={17} className={isActive ? "text-white" : "text-stone-400"} />
            </button>
          );
        })}
      </nav>

      {/* Main content */}
      <div className="flex-1 min-w-0">
        <div className="sticky top-0 z-30 bg-gradient-to-b from-rose-50 via-rose-50/90 to-transparent px-4 pt-4 pb-2">
          <div className="flex items-center justify-between">
            <h1 className="font-extrabold text-stone-700 text-base" style={{ fontFamily: "'Baloo 2', sans-serif" }}>
              {pageMeta?.label}
            </h1>
            <button
              onClick={() => setSearchOpen(true)}
              className="w-9 h-9 rounded-full bg-white/80 shadow-sm flex items-center justify-center border border-rose-100"
            >
              <Search size={15} className="text-rose-400" />
            </button>
          </div>
        </div>
        <div className="max-w-md px-4">{renderPage()}</div>
      </div>

      {searchOpen && (
        <GlobalSearch query={query} setQuery={setQuery} onClose={() => { setSearchOpen(false); setQuery(""); }} />
      )}
    </div>
  );
}
